proj=%proj%
latex=/home/nlevisrael/texlive/bin/x86_64-linux/pdflatex 
$latex -interaction=nonstopmode --shell-escape -output-dir=out \
--jobname=$proj-clean  '\def\briefSectionGap{0} \input{%proj%.tex}'

