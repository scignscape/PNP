void _f_4146_7_(u4 pattern, QVariant& retv, n8 arg1, n8 arg2, n8 arg3, n8 arg4, minimal_fn_s0_re7_type fn,
  minimal_fn_s1_re7_type sfn, void** _this)
{
 switch(pattern)
 {
 case 1123:
  {u1 a1=*(u1*)arg1;u1 a2=*(u1*)arg2;u4 a3=*(u4*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u1,u4,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u1,u4,r8))fn)(a1,a2,a3,a4);
  } break;
 case 1132:
  {u1 a1=*(u1*)arg1;u1 a2=*(u1*)arg2;r8 a3=*(r8*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u1,r8,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u1,r8,u4))fn)(a1,a2,a3,a4);
  } break;
 case 1213:
  {u1 a1=*(u1*)arg1;u4 a2=*(u4*)arg2;u1 a3=*(u1*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u4,u1,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u4,u1,r8))fn)(a1,a2,a3,a4);
  } break;
 case 1223:
  {u1 a1=*(u1*)arg1;u4 a2=*(u4*)arg2;u4 a3=*(u4*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u4,u4,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u4,u4,r8))fn)(a1,a2,a3,a4);
  } break;
 case 1231:
  {u1 a1=*(u1*)arg1;u4 a2=*(u4*)arg2;r8 a3=*(r8*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u4,r8,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u4,r8,u1))fn)(a1,a2,a3,a4);
  } break;
 case 1232:
  {u1 a1=*(u1*)arg1;u4 a2=*(u4*)arg2;r8 a3=*(r8*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u4,r8,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u4,r8,u4))fn)(a1,a2,a3,a4);
  } break;
 case 1233:
  {u1 a1=*(u1*)arg1;u4 a2=*(u4*)arg2;r8 a3=*(r8*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,u4,r8,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,u4,r8,r8))fn)(a1,a2,a3,a4);
  } break;
 case 1312:
  {u1 a1=*(u1*)arg1;r8 a2=*(r8*)arg2;u1 a3=*(u1*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,r8,u1,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,r8,u1,u4))fn)(a1,a2,a3,a4);
  } break;
 case 1321:
  {u1 a1=*(u1*)arg1;r8 a2=*(r8*)arg2;u4 a3=*(u4*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,r8,u4,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,r8,u4,u1))fn)(a1,a2,a3,a4);
  } break;
 case 1322:
  {u1 a1=*(u1*)arg1;r8 a2=*(r8*)arg2;u4 a3=*(u4*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,r8,u4,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,r8,u4,u4))fn)(a1,a2,a3,a4);
  } break;
 case 1323:
  {u1 a1=*(u1*)arg1;r8 a2=*(r8*)arg2;u4 a3=*(u4*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,r8,u4,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,r8,u4,r8))fn)(a1,a2,a3,a4);
  } break;
 case 1332:
  {u1 a1=*(u1*)arg1;r8 a2=*(r8*)arg2;r8 a3=*(r8*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u1,r8,r8,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u1,r8,r8,u4))fn)(a1,a2,a3,a4);
  } break;
 case 2113:
  {u4 a1=*(u4*)arg1;u1 a2=*(u1*)arg2;u1 a3=*(u1*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u1,u1,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u1,u1,r8))fn)(a1,a2,a3,a4);
  } break;
 case 2123:
  {u4 a1=*(u4*)arg1;u1 a2=*(u1*)arg2;u4 a3=*(u4*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u1,u4,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u1,u4,r8))fn)(a1,a2,a3,a4);
  } break;
 case 2131:
  {u4 a1=*(u4*)arg1;u1 a2=*(u1*)arg2;r8 a3=*(r8*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u1,r8,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u1,r8,u1))fn)(a1,a2,a3,a4);
  } break;
 case 2132:
  {u4 a1=*(u4*)arg1;u1 a2=*(u1*)arg2;r8 a3=*(r8*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u1,r8,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u1,r8,u4))fn)(a1,a2,a3,a4);
  } break;
 case 2133:
  {u4 a1=*(u4*)arg1;u1 a2=*(u1*)arg2;r8 a3=*(r8*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u1,r8,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u1,r8,r8))fn)(a1,a2,a3,a4);
  } break;
 case 2213:
  {u4 a1=*(u4*)arg1;u4 a2=*(u4*)arg2;u1 a3=*(u1*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u4,u1,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u4,u1,r8))fn)(a1,a2,a3,a4);
  } break;
 case 2231:
  {u4 a1=*(u4*)arg1;u4 a2=*(u4*)arg2;r8 a3=*(r8*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,u4,r8,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,u4,r8,u1))fn)(a1,a2,a3,a4);
  } break;
 case 2311:
  {u4 a1=*(u4*)arg1;r8 a2=*(r8*)arg2;u1 a3=*(u1*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,r8,u1,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,r8,u1,u1))fn)(a1,a2,a3,a4);
  } break;
 case 2312:
  {u4 a1=*(u4*)arg1;r8 a2=*(r8*)arg2;u1 a3=*(u1*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,r8,u1,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,r8,u1,u4))fn)(a1,a2,a3,a4);
  } break;
 case 2313:
  {u4 a1=*(u4*)arg1;r8 a2=*(r8*)arg2;u1 a3=*(u1*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,r8,u1,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,r8,u1,r8))fn)(a1,a2,a3,a4);
  } break;
 case 2321:
  {u4 a1=*(u4*)arg1;r8 a2=*(r8*)arg2;u4 a3=*(u4*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,r8,u4,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,r8,u4,u1))fn)(a1,a2,a3,a4);
  } break;
 case 2331:
  {u4 a1=*(u4*)arg1;r8 a2=*(r8*)arg2;r8 a3=*(r8*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(u4,r8,r8,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(u4,r8,r8,u1))fn)(a1,a2,a3,a4);
  } break;
 case 3112:
  {r8 a1=*(r8*)arg1;u1 a2=*(u1*)arg2;u1 a3=*(u1*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u1,u1,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u1,u1,u4))fn)(a1,a2,a3,a4);
  } break;
 case 3121:
  {r8 a1=*(r8*)arg1;u1 a2=*(u1*)arg2;u4 a3=*(u4*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u1,u4,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u1,u4,u1))fn)(a1,a2,a3,a4);
  } break;
 case 3122:
  {r8 a1=*(r8*)arg1;u1 a2=*(u1*)arg2;u4 a3=*(u4*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u1,u4,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u1,u4,u4))fn)(a1,a2,a3,a4);
  } break;
 case 3123:
  {r8 a1=*(r8*)arg1;u1 a2=*(u1*)arg2;u4 a3=*(u4*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u1,u4,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u1,u4,r8))fn)(a1,a2,a3,a4);
  } break;
 case 3132:
  {r8 a1=*(r8*)arg1;u1 a2=*(u1*)arg2;r8 a3=*(r8*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u1,r8,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u1,r8,u4))fn)(a1,a2,a3,a4);
  } break;
 case 3211:
  {r8 a1=*(r8*)arg1;u4 a2=*(u4*)arg2;u1 a3=*(u1*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u4,u1,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u4,u1,u1))fn)(a1,a2,a3,a4);
  } break;
 case 3212:
  {r8 a1=*(r8*)arg1;u4 a2=*(u4*)arg2;u1 a3=*(u1*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u4,u1,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u4,u1,u4))fn)(a1,a2,a3,a4);
  } break;
 case 3213:
  {r8 a1=*(r8*)arg1;u4 a2=*(u4*)arg2;u1 a3=*(u1*)arg3;r8 a4=*(r8*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u4,u1,r8))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u4,u1,r8))fn)(a1,a2,a3,a4);
  } break;
 case 3221:
  {r8 a1=*(r8*)arg1;u4 a2=*(u4*)arg2;u4 a3=*(u4*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u4,u4,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u4,u4,u1))fn)(a1,a2,a3,a4);
  } break;
 case 3231:
  {r8 a1=*(r8*)arg1;u4 a2=*(u4*)arg2;r8 a3=*(r8*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,u4,r8,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,u4,r8,u1))fn)(a1,a2,a3,a4);
  } break;
 case 3312:
  {r8 a1=*(r8*)arg1;r8 a2=*(r8*)arg2;u1 a3=*(u1*)arg3;u4 a4=*(u4*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,r8,u1,u4))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,r8,u1,u4))fn)(a1,a2,a3,a4);
  } break;
 case 3321:
  {r8 a1=*(r8*)arg1;r8 a2=*(r8*)arg2;u4 a3=*(u4*)arg3;u1 a4=*(u1*)arg4;
   auto _sfn = (QVariant(_min_::*)(r8,r8,u4,u1))(sfn);
   if(_this) retv=((_min_*)*_this->*_sfn)(a1,a2,a3,a4);
   else retv=((QVariant(*)(r8,r8,u4,u1))fn)(a1,a2,a3,a4);
  } break;
  //end of switch
 }
}

